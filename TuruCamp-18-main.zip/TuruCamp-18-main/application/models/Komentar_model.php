<?php 
    class Komentar_model extends CI_Model {
    
    }

?>