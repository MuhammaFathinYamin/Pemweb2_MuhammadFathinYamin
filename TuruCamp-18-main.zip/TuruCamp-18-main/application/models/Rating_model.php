<?php 
    class Rating_model extends CI_Model {

    
    }

?>