<?php 
    class Kecamatan_model extends CI_Model {
        
    }

?>