<?php 
    class TmpWisata_model extends CI_Model {

    
    }

?>