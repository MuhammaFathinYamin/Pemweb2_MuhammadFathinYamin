<?php 
    class JenisWisata_model extends CI_Model {
        
    
    }

?>